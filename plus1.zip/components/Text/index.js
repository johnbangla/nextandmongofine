export { Text, TextLink } from './Text';
