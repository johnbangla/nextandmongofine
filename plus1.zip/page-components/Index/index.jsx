import Hero from './Hero';

export const Index = () => {
  return <Hero />;
};
