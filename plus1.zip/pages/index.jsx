import { Index } from '@/page-components/Index';

const IndexPage = () => {
  return <Index />;
};

export default IndexPage;
